import json
import os

import boto3

# grab environment variables
ENDPOINT_NAME = os.environ['ENDPOINT_NAME']
runtime = boto3.client('runtime.sagemaker')


def lambda_handler(event, context):
    print("Received event: " + json.dumps(event, indent=2))

    payload = json.dumps({"input_text": event["input_text"]})

    print(payload)
    response = runtime.invoke_endpoint(EndpointName=ENDPOINT_NAME,
                                       ContentType='application/json',
                                       Body=payload)

    # Assuming 'response' contains the response received from the AWS service
    response_body = response['Body'].read()

    return response_body
